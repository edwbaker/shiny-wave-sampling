#' Show a wave being sampled
#'
#' @param wave A Wave object
#' @param plot_every Sample rate to show
#' @param col Colour for the sample segments. If \code{NULL}, uses
#'   the current \code{par("fg")} value.
#' @importFrom graphics abline segments
#' @export
waveSampling <- function(wave, plot_every, col = NULL){
  if (is.null(col)) col <- par("col")
  n <- floor(length(wave@left)/plot_every)

  x <- seq(from=1, by=plot_every, length.out=n)
  y <- wave@left[x]

  plot(wave@left, type="l", xlab="Time", xaxt="n", ylab="Amplitude")
  abline(h=0)
  segments(x,0,x,y, col=col)
}

#' Show a sampled wave
#'
#' @param wave A Wave object
#' @param plot_every Sample rate to show
#' @param sample.depth Number of sampling levels to use
#' @param show_wave Logical. Whether to plot the waveform.
#' @param col Colour for the bars. If \code{NULL}, uses the current
#'   \code{par("col")} value.
#' @param wave_col Colour for the waveform line. If \code{NULL}, uses
#'   the current \code{par("fg")} value.
#' @importFrom graphics barplot lines
#' @export
waveSampled <- function(wave, plot_every, sample.depth, show_wave=T, col=NULL, wave_col=NULL){
  if (is.null(col)) col <- par("col")
  if (is.null(wave_col)) wave_col <- par("fg")
  half <- sample.depth %/% 2
  n <- floor(length(wave@left)/plot_every)

  x <- seq(from=1, by=plot_every, length.out=n)
  y <- wave@left[x]

  if (sample.depth %% 2 == 0) {
    adc <- (-(half - 1):half) / half
  } else {
    adc <- (-half:half) / half
  }

  y <- adc[findInterval(y, adc)]

  barplot(
    y,
    xlab="Time",
    xaxt="n",
    width=plot_every,
    space=0,
    ylab="Amplitude",
    ylim=c(-1,1),
    col=col,
    border=col)
  if (show_wave) {
    lines(1:length(wave@left), wave@left, col=wave_col)
  }
  abline(h=0)
}
